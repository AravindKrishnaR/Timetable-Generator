-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2019 at 01:26 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `timetable`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `Cname` varchar(100) NOT NULL,
  `C_code` varchar(20) NOT NULL,
  `No_of_classes` int(10) DEFAULT NULL,
  `No_of_Labs` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`Cname`, `C_code`, `No_of_classes`, `No_of_Labs`) VALUES
('ENVIRONMENTAL SCIENCES', 'CHY1002', 3, 0),
('ENGINEERING CHEMISTRY', 'CHY1701', 3, 2),
('DIGITAL LOGICS AND DESIGN', 'CSE1003', 3, 2),
('NETWORKS AND COMMUNICATION', 'CSE1004', 3, 2),
('COMPUTER ARCHITECTURE AND DESIGN', 'CSE2001', 3, 0),
('THEORY OF COMPUTATION AND COMPILER DESIGN', 'CSE2002', 4, 0),
('DATA STRUCTURES AND ALGORITHMS', 'CSE2003', 2, 2),
('DATABASE MANAGEMENT SYSTEMS', 'CSE2004', 2, 2),
('SOFTWARE ENGINEERING', 'CSE3001', 2, 2),
('BASIC ELECTRICAL AND ELECTRONICS ENGINEERING', 'EEE1001', 2, 2),
('ETHICS AND VALUES', 'HUM1021', 2, 0),
('STATISTICS FOR ENGINEERS', 'MAT2001', 3, 2),
('CALCULUS FOR ENGINEERS', 'MAT2002', 3, 2),
('ENGINEERING PHYSICS', 'PHY1701', 3, 2),
('INTRODUCTION TO INNOVATIVE PROJECTS', 'PHY1999', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `Fno` varchar(25) NOT NULL,
  `Fname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`Fno`, `Fname`) VALUES
('F1', 'Dr. A'),
('F10', 'Dr. AA'),
('F2', 'Dr. B'),
('F20', 'Dr. BB'),
('F3', 'Dr. C'),
('F30', 'Dr. CC'),
('F4', 'Dr. D'),
('F40', 'Dr. DD'),
('F5', 'Dr. E'),
('F50', 'Dr. EE'),
('F6', 'Dr. F'),
('F60', 'Dr. FF'),
('F7', 'Dr. G'),
('F70', 'Dr. GG'),
('F8', 'Dr. H'),
('F80', 'Dr. HH'),
('F9', 'Dr. I'),
('F90', 'Dr. II');

-- --------------------------------------------------------

--
-- Table structure for table `fac_and_course`
--

CREATE TABLE `fac_and_course` (
  `PK` int(100) NOT NULL,
  `Fno` varchar(25) NOT NULL,
  `C_code` varchar(20) NOT NULL,
  `SlotType` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fac_and_course`
--

INSERT INTO `fac_and_course` (`PK`, `Fno`, `C_code`, `SlotType`) VALUES
(1, 'F1', 'CSE1003', 'M'),
(2, 'F1', 'CSE2001', 'M'),
(3, 'F2', 'CHY1701', 'M'),
(4, 'F2', 'CHY1002', 'M'),
(5, 'F3', 'MAT2002', 'M'),
(6, 'F3', 'MAT2001', 'M'),
(7, 'F4', 'CSE2004', 'M'),
(8, 'F4', 'CSE2003', 'M'),
(9, 'F5', 'EEE1001', 'M'),
(10, 'F5', 'CSE1004', 'M'),
(11, 'F6', 'PHY1701', 'M'),
(12, 'F6', 'PHY1999', 'M'),
(13, 'F7', 'CSE1003', 'M'),
(14, 'F8', 'CSE2002', 'M'),
(16, 'F10', 'CSE1003', 'A'),
(17, 'F10', 'CSE2001', 'A'),
(18, 'F20', 'CHY1701', 'A'),
(19, 'F20', 'CHY1002', 'A'),
(20, 'F30', 'MAT2001', 'A'),
(21, 'F30', 'MAT2002', 'A'),
(22, 'F40', 'CSE2003', 'A'),
(23, 'F40', 'CSE2004', 'A'),
(24, 'F50', 'CSE1004', 'A'),
(25, 'F50', 'EEE1001', 'A'),
(26, 'F60', 'PHY1701', 'A'),
(27, 'F60', 'PHY1999', 'A'),
(30, 'F70', 'CSE1003', 'A'),
(31, 'F80', 'CSE2002', 'A'),
(37, 'F9', 'CSE3001', 'M'),
(41, 'F90', 'CSE3001', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `fac_course_slot`
--

CREATE TABLE `fac_course_slot` (
  `PK` int(100) NOT NULL,
  `Fno` varchar(25) NOT NULL,
  `C_code` varchar(20) NOT NULL,
  `Slot` varchar(20) NOT NULL,
  `Year` int(10) NOT NULL,
  `Dept` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fac_course_slot`
--

INSERT INTO `fac_course_slot` (`PK`, `Fno`, `C_code`, `Slot`, `Year`, `Dept`) VALUES
(1, 'F2', 'CHY1701', 'B1+TB1', 1, 'CSE'),
(2, 'F2', 'CHY1002', 'A1+TA1', 1, 'CSE'),
(3, 'F1', 'CSE1003', 'D1+TD1', 1, 'CSE'),
(4, 'F6', 'PHY1701', 'C1+TC1', 1, 'CSE'),
(5, 'F7', 'CSE1003', 'D1+TD1', 1, 'CSE'),
(6, 'F4', 'CSE2004', 'E1', 1, 'CSE'),
(7, 'F5', 'EEE1001', 'F1', 1, 'CSE'),
(8, 'F1', 'CSE2001', 'B1+TB1', 2, 'CSE'),
(9, 'F3', 'MAT2001', 'C1+TC1', 2, 'CSE'),
(10, 'F4', 'CSE2003', 'F1', 2, 'CSE'),
(11, 'F8', 'CSE2002', 'D1+TD1+TDD1', 2, 'CSE'),
(12, 'F9', 'CSE3001', 'E1', 2, 'CSE'),
(13, 'F5', 'CSE1004', 'A1+TA1', 2, 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `theoryslots`
--

CREATE TABLE `theoryslots` (
  `Tslot` varchar(20) NOT NULL,
  `Equvi_Lslot` varchar(20) NOT NULL,
  `A_Tslot` varchar(20) NOT NULL,
  `No_of_classes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `theoryslots`
--

INSERT INTO `theoryslots` (`Tslot`, `Equvi_Lslot`, `A_Tslot`, `No_of_classes`) VALUES
('A1', 'L1,L14', 'A2', 2),
('A1+TA1', 'L1,L27,L14', 'A2+TA2', 3),
('A1+TA1+TAA1', 'L1,L27,L14,L11', 'A2+TA2+TAA2', 4),
('B1', 'L7,L20', 'B2', 2),
('B1+TB1', 'L7,L4,L20', 'B2+TB2', 3),
('C1', 'L13,L26', 'C2', 2),
('C1+TC1', 'L13,L10,L26', 'C2+TC2', 3),
('C1+TC1+TCC1', 'L13,L10,L26,L23', 'C2+TC2+TCC2', 4),
('D1', 'L19,L3', 'D2', 2),
('D1+TD1', 'L19,L16,L3', 'D2+TD2', 3),
('D1+TD1+TDD1', 'L19,L16,L3,L29', 'D2+TD2+TDD2', 4),
('E1', 'L25,L9', 'E2', 2),
('E1+TE1', 'L25,L22,L9', 'E2+TE2', 3),
('F1', 'L2,L15', 'F2', 2),
('F1+TF1', 'L2,L28,L15', 'F2+TF2', 3),
('G1', 'L21,L8', 'G2', 2),
('G1+TG1', 'L21,L5,L8', 'G2+TG2', 3),
('TAA1', 'L11', 'TAA2', 1),
('TCC1', 'L23', 'TCC2', 1),
('TDD1', 'L29', 'TDD2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `view`
--

CREATE TABLE `view` (
  `Fno` varchar(25) NOT NULL,
  `C_code` varchar(20) NOT NULL,
  `Slot` varchar(20) NOT NULL,
  `Year` int(10) NOT NULL,
  `Dept` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`C_code`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`Fno`);

--
-- Indexes for table `fac_and_course`
--
ALTER TABLE `fac_and_course`
  ADD PRIMARY KEY (`PK`),
  ADD KEY `Fno` (`Fno`),
  ADD KEY `C_code` (`C_code`);

--
-- Indexes for table `fac_course_slot`
--
ALTER TABLE `fac_course_slot`
  ADD PRIMARY KEY (`PK`),
  ADD KEY `Fno` (`Fno`),
  ADD KEY `C_code` (`C_code`),
  ADD KEY `Slot` (`Slot`);

--
-- Indexes for table `theoryslots`
--
ALTER TABLE `theoryslots`
  ADD PRIMARY KEY (`Tslot`),
  ADD UNIQUE KEY `A_Tslot` (`A_Tslot`);

--
-- Indexes for table `view`
--
ALTER TABLE `view`
  ADD KEY `Fno` (`Fno`),
  ADD KEY `C_code` (`C_code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fac_and_course`
--
ALTER TABLE `fac_and_course`
  MODIFY `PK` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `fac_course_slot`
--
ALTER TABLE `fac_course_slot`
  MODIFY `PK` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `fac_and_course`
--
ALTER TABLE `fac_and_course`
  ADD CONSTRAINT `fac_and_course_ibfk_1` FOREIGN KEY (`Fno`) REFERENCES `faculty` (`Fno`),
  ADD CONSTRAINT `fac_and_course_ibfk_2` FOREIGN KEY (`C_code`) REFERENCES `course` (`C_code`);

--
-- Constraints for table `fac_course_slot`
--
ALTER TABLE `fac_course_slot`
  ADD CONSTRAINT `fac_course_slot_ibfk_1` FOREIGN KEY (`Fno`) REFERENCES `faculty` (`Fno`),
  ADD CONSTRAINT `fac_course_slot_ibfk_2` FOREIGN KEY (`C_code`) REFERENCES `course` (`C_code`),
  ADD CONSTRAINT `fac_course_slot_ibfk_3` FOREIGN KEY (`Slot`) REFERENCES `theoryslots` (`Tslot`);

--
-- Constraints for table `view`
--
ALTER TABLE `view`
  ADD CONSTRAINT `view_ibfk_1` FOREIGN KEY (`Fno`) REFERENCES `faculty` (`Fno`),
  ADD CONSTRAINT `view_ibfk_2` FOREIGN KEY (`C_code`) REFERENCES `course` (`C_code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
